# Deployment

## Static website
Open `index.html` locally or deploy the project to GitHub Pages, Netlify, Vercel or another static-site host.

## GitHub
Repository name:
`AI-Productivity-Assistant`

Suggested commands:

```bash
git init
git add .
git commit -m "WorkSmart AI final project"
git branch -M main
git remote add origin https://github.com/TshidisoOmo/AI-Productivity-Assistant.git
git push -u origin main
```

The current files are deployment-ready, but a public live URL requires publishing through a hosting provider.
